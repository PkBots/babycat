const menu =  ` 
  🇲🇨🇲🇨☆[ 𝘿𝘼𝙏𝘼 𝘽𝙊𝙏 ] ☆🇲🇨🇲🇨
▪ ᴄʀᴇᴀᴛᴏʀ : @6285608542562
▪ ʙᴏᴛ ɴᴀᴍᴇ : Pantek Store
▪ ᴏᴡɴᴇʀ ɴᴀᴍᴇ : Gold D Dolly 
▪ ꜱɪɴᴄᴇ : 2017
▪ ᴛᴇᴀᴍ : PK°BotS
▪ ʀᴇɢɪᴏɴ : indonesia 🇲🇨
▪ ʙᴏᴛ ᴛʏᴘᴇ  : Bot-MD
           𝐢𝐧𝐟𝐨 𝐬𝐞𝐰𝐚 & 𝐬𝐜𝐫𝐢𝐩𝐭
 ➤ Premium/Sewa Bot
    •1 Months IDR 10k
    •1 Years IDR 100k
 ➤ScriptMD IDR 20k
 ➤ScriptMD + Panel IDR 25k
 ➤Ready OTP IM3 IDR 5k All APK
╔══ ☆𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ☆══
╠➤ ALLMENU
╠➤ OWNERMENU
╠➤ DOWNLOADMENU
╠➤ GROUPMENU
╠➤ BUGMENU
╠➤ GAMEMENU
╠➤ LISTMENU
╠➤ TEXTMAKER
╠➤ JUALAN
╠➤ LAYANAN
╠➤ ANTILINK (ON/OFF)
╠➤ WELCOME (ON/OFF)
╠➤ ANTITOXIC (ON/OFF)
        https://sites.google.com/view/pantekstore
   `
exports.menu = menu