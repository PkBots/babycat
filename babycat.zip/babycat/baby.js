// Buat Lu Yang Jual Sc Ini Yang Jujur Jangan Samp Nipu Apalagi Lari Dari Tanggung Jawab

// Base Haikal Hw Mods : Copyan Dari Base Dika


const fs = require('fs')
const chalk = require('chalk')
const tiktok = require("./babycatBot/lib/tiktok")
const facebook = require("./babycatBot/lib/facebook")
const instagram = require("./babycatBot/lib/instagram")
const twitter = require("./babycatBot/lib/twitter")

global.ntnsfww = []
global.wlcm = []
global.wlcmm = []
//gausah di apa² in!
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
//=================================================//
//—————「 Set Kebutuhan Button & Kontak 」—————//
//ubah aja kalau ada yang gapunya gsh di hps anggap aja credits :), note tanda ' gausah di hapus!
global.youtube = 'https://youtube.com/c/72hsoa8' // ubah aia
global.ig = '@fywhl.dx17' // ubah aja
global.email = 'pantekstore182@gmail.com' //serah
global.region = 'indonesia' // serah
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'Gol D Dolly' //ubah jadi nama mu, note tanda ' gausah di hapus!
global.botname = 'PANTEK STORE' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.footer = 'PkBotS' //ubah jadi nama mu, note tanda ' gausah di hapus!
//=================================================//
global.owner = ['6285608542562'] // ubah aja pake nomor lu
global.creator = "6285608542562@s.whatsapp.net"
global.premium = ['6285608542562'] // ubah aja pake nomor lu
global.keyopenai = "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"
global.packname = 'Dolly' // ubah aja
global.ownerr = ['Gol D Dolly'] // ubaha aja
global.author = 'PkBots' //ubah aja
global.prefa = ['','!','.','🐦','🐤','🗿']
global.sessionName = 'haikal' //Gausah Juga
global.sp = '⭔' // Gausah Juga

// Terserah
global.mess = {
    nsfw: '*Fitur NSFW tidak diaktifkan, chat admin grup supaya diaktifkan*_',
    owner: 'Maaf Kamu Bukan Pengguna Premium',
 }
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 10
}
//=================================================//
//Terserah Kalau Paham 
global.thumb = fs.readFileSync("./babycatBot/image/pk.jpg")
global.log0 = fs.readFileSync("./babycatBot/image/babycat.jpg")
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})